#pragma once
#include "../oscilloscope/sketch/wav_protocol.h"
namespace wav_hw {
static uint32_t data[scope_wav::SLOTS*scope_wav::POINTS];
}
