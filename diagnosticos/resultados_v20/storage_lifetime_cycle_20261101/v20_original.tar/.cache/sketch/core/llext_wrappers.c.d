/home/arduino/ArduinoApps/scope-v20-20261031-225916/.cache/sketch/core/llext_wrappers.c.o: \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/llext_wrappers.c \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h
