#line 1 "/home/arduino/ArduinoApps/scope-v18-rate-probe-catalog/sketch/generator_protocol.h"
#pragma once
#include "control_protocol.h"
namespace scope_gen {
using namespace scope_control;
constexpr uint16_t SET_GENERATOR=8, GENERATOR_STATUS=9, GET_GENERATOR=10;
constexpr uint32_t UPDATE_HZ=1000000;
constexpr uint32_t MAX_FREQUENCY_MHZ=200000000;
inline uint32_t waveform_limit(uint8_t wave) {
    return wave==0?200000000U:wave==1?150000000U:50000000U;
}
constexpr uint32_t CONTROL_HZ=2000;
struct Config {
    uint8_t wave, enabled, mode;
    uint32_t frequency, final_frequency;
    uint16_t low, high;
    uint32_t duration;
    uint8_t duration_us=0;
    uint8_t duty=50;
};
inline Config defaults() { return {0,0,0,2500,2500,0,4095,1000}; }
inline bool equal(const Config &a,const Config &b) {
    return a.wave==b.wave && a.enabled==b.enabled && a.mode==b.mode &&
        a.frequency==b.frequency && a.final_frequency==b.final_frequency &&
        a.low==b.low && a.high==b.high && a.duration==b.duration && a.duration_us==b.duration_us && a.duty==b.duty;
}
inline bool valid(const Config &c) {
    if(c.mode==3) return c.wave==1 && c.enabled<=1 && !c.duration_us && c.duty==50 &&
        c.frequency<=50000000 && c.frequency%25000==0 &&
        c.final_frequency<=50000000 && c.final_frequency%25000==0 &&
        (!c.frequency || c.frequency!=c.final_frequency) && c.duration<=5000 && c.duration%25==0 && c.low<=c.high && c.high<=4095;
    return c.wave<=4 && c.enabled<=1 && c.mode<=2 && c.frequency>=100 && c.frequency<=waveform_limit(c.wave) &&
        c.final_frequency>=100 && c.final_frequency<=waveform_limit(c.wave) && c.low<=c.high && c.high<=4095 &&
        (c.duration_us ? (c.duration_us==1 && c.wave==4 && !c.mode && c.duration>=100 && c.duration<=65535) : (c.duration>=1 && c.duration<=600000)) && (c.wave!=4 || c.mode==0) && c.duty>=1 && c.duty<=99 && (c.duty==50 || (!c.wave && !c.mode));
}
inline Config read(const uint8_t *p,uint8_t duty=0) {
    return {p[0],p[1],p[2],scope_control::get32(p+4),scope_control::get32(p+8),
        uint16_t(p[12]|uint16_t(p[13])<<8),uint16_t(p[14]|uint16_t(p[15])<<8),scope_control::get32(p+16),p[3],uint8_t(duty?duty:50)};
}
inline void write(uint8_t *p,const Config &c) {
    p[0]=c.wave; p[1]=c.enabled; p[2]=c.mode;p[3]=c.duration_us;
    scope_control::put32(p+4,c.frequency);scope_control::put32(p+8,c.final_frequency);
    p[12]=uint8_t(c.low);p[13]=uint8_t(c.low>>8);p[14]=uint8_t(c.high);p[15]=uint8_t(c.high>>8);
    scope_control::put32(p+16,c.duration);
}
struct Request { uint32_t id; Config config; bool query; };
struct Reply { uint32_t id; uint8_t phase, reason, running; Config active, requested; };
inline bool decode(const uint8_t *p,size_t size,Request &r) {
    if(size!=992 || memcmp(p,"SCP1",4) || p[4]!=4 || p[5] || p[7] ||
        (p[6]!=8 && p[6]!=10) || scope_control::get32(p+12)!=972 || !scope_control::pc_id(scope_control::get32(p+8)) ||
        scope_control::get32(p+988)!=scope_control::crc(p,988)) return false;
    const bool query=p[6]==10;
    if(!query && (p[19]>1 || (p[19] && (p[16]!=4 || p[18])))) return false;
    for(unsigned i=query?16:37;i<988;++i) if(p[i]) return false;
    r={scope_control::get32(p+8),query?defaults():read(p+16,p[36]),query};return true;
}
inline void encode(uint8_t *p,uint32_t seq,const Reply &r) {
    memset(p,0,992);memcpy(p,"SCP1",4);p[4]=4;p[6]=9;scope_control::put32(p+8,seq);scope_control::put32(p+12,972);
    scope_control::put32(p+16,r.id);p[20]=r.phase;p[21]=r.reason;p[22]=r.running;p[23]=31;
    write(p+24,r.active);write(p+44,r.requested);
    p[64]=r.active.duty==50?0:r.active.duty;p[65]=r.requested.duty==50?0:r.requested.duty;scope_control::put32(p+988,scope_control::crc(p,988));
}
}
