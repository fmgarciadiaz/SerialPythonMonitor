/home/arduino/ArduinoApps/scope-v18-rate-probe-batcharena/.cache/sketch/core/itoa.cpp.o: \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/itoa.cpp \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/itoa.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/deprecated-avr-comp/avr/dtostrf.c.impl
