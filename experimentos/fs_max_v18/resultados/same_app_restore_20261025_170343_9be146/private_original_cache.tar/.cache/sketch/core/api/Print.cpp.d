/home/arduino/ArduinoApps/scope-v18-rate-probe-rateonly/.cache/sketch/core/api/Print.cpp.o: \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/Print.cpp \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/Print.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/String.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/deprecated-avr-comp/avr/pgmspace.h \
 /home/arduino/.arduino15/internal/arduino_zephyr_1.0.0_280fc2760e675f10/cores/arduino/api/Printable.h
