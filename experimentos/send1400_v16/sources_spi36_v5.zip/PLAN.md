# ADC8 CH1: envío mejorado para 1,4 MHz

Fuentes y aplicación independientes de V16 y del barrido maxfreq anterior.
v1–v4 solicitan SPI a 32 MHz; v5 solicita 36 MHz. Tramas kind20/SCP1 V4 de
992 bytes conservadas. La frecuencia solicitada no certifica el reloj físico.

Variantes ensayadas (fuentes previas archivadas en ZIP):

- v2: sustituye el pipeline por la espera original y reutiliza la configuración
  DMA SPI sólo después de confirmar que los canales quedaron detenidos/reset.
- v3: agrega O3 y desenrollado de cuatro iteraciones a validación/copia;
  sigue comprobando cada timestamp y cada valor ADC.
- v4: agrega O3 al productor, construcción de fragmentos e hilo de salida;
  desenrolla ocho muestras en el empaquetado ADC8, conservando sus colas.

- v5: parte de v3 y solicita SPI a 36 MHz en el relay. Antes de compilar
  el relay se detienen adquisición y aplicación estable después del snapshot
  y respaldo; el snapshot se conserva hasta la restauración exacta.

Cambios v1:

- Preparar hasta tres fragmentos mientras SPI transmite el anterior. La copia
  del nodo sigue siendo inmutable y sólo se libera al completar físicamente
  el último fragmento. Los ACK de control conservan prioridad.
- En ADC8 cada byte representa un valor válido. El relay conserva CRC,
  metadatos, padding y límites de nodo; comprueba continuidad de índice y
  timestamp por los extremos del fragmento, cuya progresión interna es fija.
  No se eliminan bytes ni timestamps del protocolo.
- Consumir un evento READY ya encolado antes de llamar poll. Se mantienen
  secuencia de eventos, timeout y descarte de créditos anteriores al I/O.

Pruebas locales: constructor/decodificadores C y Python con wraps y corrupción;
comparación del validador anterior contra el optimizado con tramas válidas y
campos/padding/CRC corruptos. Compilación MCU/relay antes de medir.

Ensayo físico: un dueño Q, snapshot vivo y respaldo antes de preparar;
caffeinate y diferencia pared/monotónico. Referencia ADC8/131 ticks/N6912
durante 10 s. Después ticks115 y114 (1,391304 y1,403509 MHz), nodos3456,
6912 y8192 durante 5 s más 1 s de estabilización, con reinicio independiente.

Sólo perfiles que pasan avanzan a 60 s + 3×120 s + 600 s. Exigir CRC,
secuencia, epoch, índices/timestamps, DMA, dropped=fatal=0. Informar integridad
por separado del margen: >=10% envío medio, cola pico<4 y slack positivo.
No se promueve ninguna tasa a la UI de producción en esta campaña.

Finalmente se restaura la aplicación y el relay de producción, todos los
campos previos, identidad/hash de firmware y diez segundos de continuidad.
Resultados por caso persistidos, con fuentes/hashes y errores de arranque
separados de los resultados de adquisición. Precisión analógica no evaluada.

Pruebas adicionales v4: `test_validation.py` comprueba CH1, wraps, colas
de bucles (1/3/4/7/8/9/257/416/864/8192 muestras), corrupción en cada
posición y que el empaquetado ADC8 no escriba fuera de su salida.
