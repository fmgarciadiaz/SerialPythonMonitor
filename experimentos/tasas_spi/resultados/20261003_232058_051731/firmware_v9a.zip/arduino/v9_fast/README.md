# V9 Fast SPI · firmware experimental

Derivado de V8 config, con app independiente y receptor/relay separados.
Candidatos nativos SPI: 100, 125, 200 y 250 kHz por canal. Mantiene 16 bits
con oversampling hasta 50 kHz y UART hasta 31,25 kHz. Pines A0/A2/A3 originales.

**Todavía no validado físicamente.** Python V10 + V8 config siguen siendo el
conjunto actual. Las tasas altas se ensayan desde el receptor CLI experimental.

[Estudio, pruebas, respaldo y restauración](../../experimentos/tasas_spi/README.md).

```sh
python3 tools/unoq.py compile --version v9_fast
python3 tools/usb_stream.py build --firmware v9_fast
```

La app experimental está importada, pero no se inició ni se cargó durante la
preparación. La compilación ocupa 101 024 bytes de programa y 156 296 bytes
estáticos, con 105 848 bytes de RAM restantes según Arduino CLI.
