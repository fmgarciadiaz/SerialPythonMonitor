#pragma once
#include "generator_protocol.h"
namespace radio_test {
constexpr unsigned POINTS=256;
constexpr unsigned RATE=256000;
inline bool valid(const scope_gen::Config &c) {
    return c.wave==1 && c.enabled<=1 && c.mode==3 && !c.duration_us && c.duty==50 &&
        c.frequency>=1000000 && c.frequency<=50000000 && c.frequency%1000000==0 &&
        c.final_frequency>=1000000 && c.final_frequency<=50000000 && c.final_frequency%1000000==0 &&
        c.frequency!=c.final_frequency && c.duration<=5000 && c.duration%1000==0 &&
        c.low<=c.high && c.high<=4095;
}
inline uint16_t sample(const scope_gen::Config &c,unsigned i,const uint16_t *sine) {
    const int32_t tone=c.duration?int32_t(sine[(i*(c.duration/1000))&255])-32768:0;
    const int32_t first=int32_t(sine[(i*(c.frequency/1000000)+64)&255])-32768;
    const int32_t second=int32_t(sine[(i*(c.final_frequency/1000000)+64)&255])-32768;
    int32_t unit=32768+(first+second)*(16384+tone/4)/49152;
    if(unit<0)unit=0;if(unit>65535)unit=65535;
    return c.low+uint16_t((uint32_t(c.high-c.low)*uint32_t(unit)+32767)/65535);
}
}
