#include <Arduino.h>
#include <Arduino_RouterBridge.h> // Dependencia del core, sin transporte RPC.
#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/irq.h>
#include <stm32u5xx.h>
#include <stm32u5xx_ll_dma.h>
#include <stm32u5xx_ll_dcache.h>
#include "benchmark_protocol.h"

#if !defined(CONFIG_SOC_STM32U585XX)
#error "Sólo UNO Q STM32U585"
#endif

using namespace scope_bench;
#define SPI_NODE DT_NODELABEL(spi3)
static const device *const spi_device = DEVICE_DT_GET(SPI_NODE);
static_assert(DT_REG_ADDR(SPI_NODE) == SPI3_BASE, "Revisar mapa SPI3");
static_assert(BLOCK_BYTES <= 1023, "SPI3 tiene TSIZE limitado a 10 bits");
static constexpr uint32_t ERROR_FLAGS = SPI_SR_UDR | SPI_SR_OVR | SPI_SR_CRCE |
                                        SPI_SR_TIFRE | SPI_SR_MODF;
static constexpr uint32_t CLEAR_FLAGS = SPI_IFCR_EOTC | SPI_IFCR_TXTFC |
    SPI_IFCR_UDRC | SPI_IFCR_OVRC | SPI_IFCR_CRCEC | SPI_IFCR_TIFREC |
    SPI_IFCR_MODFC | SPI_IFCR_SUSPC;
static constexpr uint32_t ACTIVE_TIMEOUT_US = 50000;
static_assert(BLOCK_BYTES % CONFIG_DCACHE_LINE_SIZE == 0, "DMA cache alignment");
static uint8_t tx[BLOCK_BYTES] __attribute__((aligned(CONFIG_DCACHE_LINE_SIZE)));
static uint8_t rx[BLOCK_BYTES] __attribute__((aligned(CONFIG_DCACHE_LINE_SIZE)));
static DMA_Channel_TypeDef *const tx_dma = GPDMA1_Channel2;
static DMA_Channel_TypeDef *const rx_dma = GPDMA1_Channel3;
static constexpr uint32_t DMA_ERRORS = DMA_CSR_DTEF | DMA_CSR_ULEF | DMA_CSR_USEF | DMA_CSR_TOF;
static volatile uint32_t fault_dma = 0;
static uint32_t sequence = 0, last_ping = 0xffffffffU;
static uint32_t spi_errors = 0, bad_ping = 0, short_transfers = 0;
static int32_t last_result = 0, last_error = 0;
static uint32_t prepare_us = 0, check_us = 0;
static volatile uint32_t fault_sr = 0;
static bool ready = false;
static struct k_sem transfer_done;
static volatile bool completed = false;
static constexpr uint32_t DMA_IRQS = DMA_CCR_TCIE | DMA_CCR_DTEIE |
    DMA_CCR_ULEIE | DMA_CCR_USEIE | DMA_CCR_TOIE;
static constexpr uint32_t SPI_IRQS = SPI_IER_EOTIE | SPI_IER_UDRIE |
    SPI_IER_OVRIE | SPI_IER_CRCEIE | SPI_IER_TIFREIE | SPI_IER_MODFIE;
static inline void publish_ready(bool value) {
    GPIOG->BSRR = value ? (1U << 13) : (1U << (13 + 16));
    __DSB();
}
// Las tres IRQ tienen la misma prioridad: no se anidan entre sí.
static void transfer_isr(const void *) {
    const uint32_t sr = SPI3->SR, ts = tx_dma->CSR, rs = rx_dma->CSR;
    if (sr & ERROR_FLAGS) fault_sr = sr;
    if ((ts | rs) & DMA_ERRORS)
        fault_dma = ((ts & DMA_ERRORS) >> 8) | ((rs & DMA_ERRORS) << 8);
    // Se retiran las fuentes atendidas; las banderas quedan hasta que el hilo
    // cierre la transacción, permitiendo comprobar EOT + ambos TC sin carreras.
    if (sr & (SPI_SR_EOT | ERROR_FLAGS)) SPI3->IER = 0;
    if (ts & (DMA_CSR_TCF | DMA_ERRORS)) tx_dma->CCR &= ~DMA_IRQS;
    if (rs & (DMA_CSR_TCF | DMA_ERRORS)) rx_dma->CCR &= ~DMA_IRQS;
    publish_ready(false);
    if (!completed && (fault_sr || fault_dma ||
        ((sr & SPI_SR_EOT) && (ts & DMA_CSR_TCF) && (rs & DMA_CSR_TCF)))) {
        SPI3->IER = 0;
        tx_dma->CCR &= ~DMA_IRQS;
        rx_dma->CCR &= ~DMA_IRQS;
        completed = true;
        k_sem_give(&transfer_done);
    }
}

// PG12 es el NSS físico de SPI3 en el UNO Q; pinctrl lo configura en AF.
static inline bool selected() { return (GPIOG->IDR & (1U << 12)) == 0; }
static inline uint32_t elapsed_us(uint32_t start) {
    return k_cyc_to_us_floor32(uint32_t(k_cycle_get_32() - start));
}
static void stop_spi() {
    SPI3->CR1 &= ~SPI_CR1_SPE;
    __DSB();
    SPI3->IFCR = CLEAR_FLAGS;
}

static void cache_maintain(void *addr, size_t len, uint32_t command)
{
    if (len == 0U) {
        return;
    }
    const unsigned int key = irq_lock();
    __DSB();
    if (LL_DCACHE_IsEnabled(DCACHE1)) {
        while (LL_DCACHE_IsActiveFlag_BUSY(DCACHE1) ||
               LL_DCACHE_IsActiveFlag_BUSYCMD(DCACHE1)) {
        }
        const uint32_t start = reinterpret_cast<uint32_t>(addr);
        LL_DCACHE_SetStartAddress(DCACHE1, start);
        LL_DCACHE_SetEndAddress(DCACHE1, start + len - 1U);
        LL_DCACHE_SetCommand(DCACHE1, command);
        LL_DCACHE_StartCommand(DCACHE1);
        while (LL_DCACHE_IsActiveFlag_BUSYCMD(DCACHE1)) {
        }
        LL_DCACHE_ClearFlag_CMDEND(DCACHE1);
    }
    __DSB();
    __ISB();
    irq_unlock(key);
}

static inline void cache_flush_invalidate(void *addr, size_t len)
{
    cache_maintain(addr, len, LL_DCACHE_COMMAND_CLEAN_INVALIDATE_BY_ADDR);
}

static inline void cache_invalidate(void *addr, size_t len)
{
    cache_maintain(addr, len, LL_DCACHE_COMMAND_INVALIDATE_BY_ADDR);
}

// Canales 2/3 dedicados al ensayo; 0/1 quedan libres para futura adquisición.
// DMA mueve los bytes; IRQ de fin/error despierta al hilo mediante semáforo.
static bool reset_dma(DMA_Channel_TypeDef *channel) {
    if (channel->CCR & DMA_CCR_EN) {
        channel->CCR |= DMA_CCR_SUSP;
        const uint32_t started = k_cycle_get_32();
        while (!(channel->CSR & (DMA_CSR_SUSPF | DMA_CSR_IDLEF))) {
            if (elapsed_us(started) >= ACTIVE_TIMEOUT_US) return false;
        }
    }
    channel->CCR = DMA_CCR_RESET;
    __DSB();
    const uint32_t started = k_cycle_get_32();
    while (channel->CCR & (DMA_CCR_RESET | DMA_CCR_EN)) {
        if (elapsed_us(started) >= ACTIVE_TIMEOUT_US) return false;
    }
    channel->CFCR = DMA_CFCR_TCF | DMA_CFCR_HTF | DMA_CFCR_DTEF |
        DMA_CFCR_ULEF | DMA_CFCR_USEF | DMA_CFCR_SUSPF | DMA_CFCR_TOF;
    return true;
}

static void configure_dma(DMA_Channel_TypeDef *channel, bool transmit) {
    channel->CCR = LL_DMA_HIGH_PRIORITY | DMA_IRQS;
    // Accesos de un byte, bursts de uno. RAM por puerto 1, SPI por puerto 0.
    channel->CTR1 = transmit ? (DMA_CTR1_SINC | DMA_CTR1_SAP)
                             : (DMA_CTR1_DINC | DMA_CTR1_DAP);
    channel->CTR2 = transmit ? (DMA_CTR2_DREQ | LL_GPDMA1_REQUEST_SPI3_TX)
                             : LL_GPDMA1_REQUEST_SPI3_RX;
    channel->CBR1 = BLOCK_BYTES;
    channel->CSAR = transmit ? reinterpret_cast<uint32_t>(tx)
                             : reinterpret_cast<uint32_t>(&SPI3->RXDR);
    channel->CDAR = transmit ? reinterpret_cast<uint32_t>(&SPI3->TXDR)
                             : reinterpret_cast<uint32_t>(rx);
    channel->CLLR = 0;
}

static int exchange() {
    publish_ready(false);
    fault_sr = fault_dma = 0;
    completed = false;
    k_sem_reset(&transfer_done);
    uint32_t started = k_cycle_get_32();
    while (selected()) {
        if (elapsed_us(started) >= ACTIVE_TIMEOUT_US) return -EBUSY;
    }
    if (!reset_dma(tx_dma) || !reset_dma(rx_dma)) {
        ready = false; // No reutilizar RAM mientras un DMA no se detuvo.
        return -ETIMEDOUT;
    }
    cache_flush_invalidate(tx, sizeof(tx));
    cache_flush_invalidate(rx, sizeof(rx));
    configure_dma(rx_dma, false);
    configure_dma(tx_dma, true);
    SPI3->CR2 = BLOCK_BYTES;
    SPI3->IFCR = CLEAR_FLAGS;
    SPI3->CFG1 = 7U | SPI_CFG1_RXDMAEN | SPI_CFG1_TXDMAEN;
    __DSB();
    rx_dma->CCR |= DMA_CCR_EN;
    tx_dma->CCR |= DMA_CCR_EN;
    SPI3->IER = SPI_IRQS;
    SPI3->CR1 = SPI_CR1_SPE;
    __DSB();
    publish_ready(true);
    int result = -EIO;
    // Idle ilimitado sin consumir CPU. La espera temporizada detecta bloques
    // truncados sin necesitar EXTI en NSS; el margen de detección es 50–100 ms.
    bool partial = false;
    for (;;) {
        if (k_sem_take(&transfer_done, K_MSEC(50)) == 0) {
            result = (fault_sr || fault_dma) ? -EIO : int(BLOCK_BYTES);
            break;
        }
        if (partial) { result = -ETIMEDOUT; break; }
        partial = selected() || rx_dma->CBR1 != BLOCK_BYTES;
    }
    publish_ready(false);
    SPI3->IER = 0;
    tx_dma->CCR &= ~DMA_IRQS;
    rx_dma->CCR &= ~DMA_IRQS;
    stop_spi();
    SPI3->CFG1 &= ~(SPI_CFG1_RXDMAEN | SPI_CFG1_TXDMAEN);
    // Detener ambos canales antes de leer o volver a escribir los buffers.
    const bool tx_stopped = reset_dma(tx_dma);
    const bool rx_stopped = reset_dma(rx_dma);
    if (!tx_stopped || !rx_stopped) { ready = false; return -ETIMEDOUT; }
    cache_invalidate(rx, sizeof(rx));
    return result;
}

void setup() {
    // El core sólo aplica clocks y pinctrl; ninguna transferencia pasa por él.
    const int result = device_init(spi_device);
    ready = (result == 0 || result == -EALREADY) && device_is_ready(spi_device);
    if (!ready) return;
    irq_disable(DT_IRQN(SPI_NODE));
    SPI3->IER = 0;
    stop_spi();
    SPI3->CR1 = 0;
    SPI3->CFG1 = 7U; // DSIZE=8 bits, FTHLV=1 byte, CRC y DMA deshabilitados.
    SPI3->CFG2 = 0;  // Peripheral, full duplex, modo 0, MSB, NSS físico activo bajo.
    SPI3->UDRDR = 0;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPDMA1EN;
    (void)RCC->AHB1ENR;
    // No apropiarse de un canal que el core ya esté utilizando.
    if ((tx_dma->CCR | rx_dma->CCR) & DMA_CCR_EN) { ready = false; return; }
    irq_disable(GPDMA1_Channel2_IRQn);
    irq_disable(GPDMA1_Channel3_IRQn);
    k_sem_init(&transfer_done, 0, 1);
    irq_connect_dynamic(DT_IRQN(SPI_NODE), 5, transfer_isr, nullptr, 0);
    irq_connect_dynamic(GPDMA1_Channel2_IRQn, 5, transfer_isr, nullptr, 0);
    irq_connect_dynamic(GPDMA1_Channel3_IRQn, 5, transfer_isr, nullptr, 0);
    NVIC_ClearPendingIRQ(SPI3_IRQn);
    NVIC_ClearPendingIRQ(GPDMA1_Channel2_IRQn);
    NVIC_ClearPendingIRQ(GPDMA1_Channel3_IRQn);
    // PG13 también habilita el loader: Linux conserva GPIO70 alto al arrancar.
    // Sólo tomar la salida cuando el receptor solicite INPUT + pull-down.
    // La espera de arranque cede CPU y no toca el loader ni Arduino Router.
    GPIOG->MODER &= ~(3U << 26);
    GPIOG->PUPDR &= ~(3U << 26);
    while (GPIOG->IDR & (1U << 13)) k_sleep(K_MSEC(1));
    publish_ready(false);
    GPIOG->OTYPER &= ~(1U << 13);
    GPIOG->PUPDR &= ~(3U << 26);
    GPIOG->OSPEEDR = (GPIOG->OSPEEDR & ~(3U << 26)) | (2U << 26);
    GPIOG->MODER = (GPIOG->MODER & ~(3U << 26)) | (1U << 26);
    irq_enable(DT_IRQN(SPI_NODE));
    irq_enable(GPDMA1_Channel2_IRQn);
    irq_enable(GPDMA1_Channel3_IRQn);
}

void loop() {
    if (!ready) { k_sleep(K_MSEC(100)); return; }
    uint32_t started = k_cycle_get_32();
    data_frame(tx, sequence, last_ping, spi_errors, bad_ping, short_transfers,
               last_result, last_error, prepare_us, check_us);
    prepare_us = elapsed_us(started);
    last_result = exchange();
    started = k_cycle_get_32();
    if (last_result < 0) {
        ++spi_errors;
        // Extensión diagnóstica sin cambiar el formato SCP1/v2:
        // DMA usa 0x02000000; SPI usa 0x10000 + SR[15:0]; resto errno.
        last_error = fault_dma ? -int32_t(0x2000000U | fault_dma) :
            (fault_sr ? -int32_t(0x10000U | (fault_sr & 0xffffU)) : last_result);
        if (last_result == -EMSGSIZE) ++short_transfers;
    } else if (last_result != int(BLOCK_BYTES)) ++short_transfers;
    else if (valid_ping(rx)) last_ping = get32(rx + 8);
    else ++bad_ping;
    check_us = elapsed_us(started);
    ++sequence;
}
