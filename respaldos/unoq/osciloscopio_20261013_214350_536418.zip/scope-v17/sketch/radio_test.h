#pragma once
#include "generator_protocol.h"
#include <math.h>
namespace radio_test {
constexpr unsigned POINTS=256;
constexpr unsigned RATE=256000;
inline bool valid(const scope_gen::Config &c) {
    return c.wave==1 && c.enabled<=1 && c.mode==3 && !c.duration_us && c.duty==50 &&
        c.frequency>=1000000 && c.frequency<=50000000 && c.frequency%1000000==0 &&
        c.final_frequency>=1000000 && c.final_frequency<=50000000 && c.final_frequency%1000000==0 &&
        c.frequency!=c.final_frequency && c.duration<=5000 && c.duration%1000==0 &&
        c.low<=c.high && c.high<=4095;
}
inline uint16_t sample(const scope_gen::Config &c,unsigned i) {
    const double phase=6.2831853071795864769*i/POINTS;
    const double tone=c.duration?sin(phase*(c.duration/1000)):0;
    const double signal=(1+.5*tone)*(cos(phase*(c.frequency/1000000))+cos(phase*(c.final_frequency/1000000)))/3;
    return uint16_t(c.low+(c.high-c.low)*(.5+.5*signal)+.5);
}
}
