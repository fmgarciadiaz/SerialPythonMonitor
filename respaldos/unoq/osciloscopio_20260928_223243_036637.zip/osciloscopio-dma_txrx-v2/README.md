# 😀 Osciloscopio




