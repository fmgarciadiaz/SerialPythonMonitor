#pragma once
#include "generator_protocol.h"
#include <math.h>
// k_timer callback runs in interrupt context: bounded integer work, direct DAC write.
// The Zephyr core config has 10,000 ticks/s. 5 ticks give exactly 2,000 updates/s.
namespace generator {
static_assert(CONFIG_SYS_CLOCK_TICKS_PER_SEC % scope_gen::UPDATE_HZ == 0, "Generator tick rate");
static k_timer timer;
static scope_gen::Config active=scope_gen::defaults();
static scope_gen::Request last{};
static bool have_last=false, running=false;
static uint32_t phase=0, elapsed=0, steps=0;
static int64_t previous_tick=0;
static uint32_t increments[129];
static const uint16_t sine[256]={32768,33572,34375,35178,35979,36779,37575,38369,39160,39947,40729,41507,42279,43046,43807,44560,45307,46046,46777,47500,48214,48919,49613,50298,50972,51635,52287,52927,53555,54170,54773,55362,55938,56499,57047,57579,58097,58600,59087,59558,60013,60451,60873,61278,61666,62036,62389,62724,63041,63339,63620,63881,64124,64348,64553,64739,64905,65053,65180,65289,65377,65446,65496,65525,65535,65525,65496,65446,65377,65289,65180,65053,64905,64739,64553,64348,64124,63881,63620,63339,63041,62724,62389,62036,61666,61278,60873,60451,60013,59558,59087,58600,58097,57579,57047,56499,55938,55362,54773,54170,53555,52927,52287,51635,50972,50298,49613,48919,48214,47500,46777,46046,45307,44560,43807,43046,42279,41507,40729,39947,39160,38369,37575,36779,35979,35178,34375,33572,32768,31963,31160,30357,29556,28756,27960,27166,26375,25588,24806,24028,23256,22489,21728,20975,20228,19489,18758,18035,17321,16616,15922,15237,14563,13900,13248,12608,11980,11365,10762,10173,9597,9036,8488,7956,7438,6935,6448,5977,5522,5084,4662,4257,3869,3499,3146,2811,2494,2196,1915,1654,1411,1187,982,796,630,482,355,246,158,89,39,10,0,10,39,89,158,246,355,482,630,796,982,1187,1411,1654,1915,2196,2494,2811,3146,3499,3869,4257,4662,5084,5522,5977,6448,6935,7438,7956,8488,9036,9597,10173,10762,11365,11980,12608,13248,13900,14563,15237,15922,16616,17321,18035,18758,19489,20228,20975,21728,22489,23256,24028,24806,25588,26375,27166,27960,28756,29556,30357,31160,31963};
static uint32_t increment(uint32_t frequency) {
    return uint32_t((uint64_t(frequency)<<32)/(1000ULL*CONFIG_SYS_CLOCK_TICKS_PER_SEC));
}
static uint16_t value(uint8_t wave,uint32_t ph,uint16_t low,uint16_t high) {
    uint32_t unit=0;
    if(wave==0) unit=ph<0x80000000U?65535:0;
    else if(wave==1) unit=sine[ph>>24];
    else if(wave==2) unit=ph<0x80000000U?ph>>15:(0xffffffffU-ph)>>15;
    else if(wave==3) unit=ph>>16;
    else unit=65535;
    return low+uint16_t((uint32_t(high-low)*unit+32767)/65535);
}
static void tick(k_timer *) {
    if(!running) return;
    const int64_t now=k_uptime_ticks();
    const uint32_t delta=uint32_t(now-previous_tick);previous_tick=now;
    elapsed+=delta;
    if((active.mode || active.wave==4) && elapsed>=steps) {
        running=false;reinterpret_cast<DAC_TypeDef *>(DAC1_BASE)->DHR12R1=active.low;return;
    }
    const unsigned pos=active.mode?unsigned(uint64_t(elapsed)*128/steps):0;
    phase+=uint32_t(uint64_t(increments[pos])*delta);
    reinterpret_cast<DAC_TypeDef *>(DAC1_BASE)->DHR12R1=value(active.wave,phase,active.low,active.high);
}
static void apply(const scope_gen::Config &c) {
    // Prepare floating-point sweep outside interrupt context; no peripheral ownership changes.
    uint32_t prepared[129];
    for(unsigned i=0;i<=128;++i) {
        double f=c.frequency;
        if(c.mode==1) f+= (double(c.final_frequency)-c.frequency)*i/128;
        else if(c.mode==2) f*=pow(double(c.final_frequency)/c.frequency,double(i)/128);
        prepared[i]=increment(uint32_t(f+0.5));
    }
    const unsigned key=irq_lock();
    active=c;memcpy(increments,prepared,sizeof(increments));
    phase=elapsed=0;steps=uint32_t(uint64_t(c.duration)*CONFIG_SYS_CLOCK_TICKS_PER_SEC/1000);
    previous_tick=k_uptime_ticks();running=c.enabled;
    reinterpret_cast<DAC_TypeDef *>(DAC1_BASE)->DHR12R1=c.enabled?value(c.wave,0,c.low,c.high):0;
    irq_unlock(key);
}
static scope_gen::Reply reply(uint32_t id,uint8_t status,uint8_t reason,const scope_gen::Config &wanted) {
    const unsigned key=irq_lock();
    scope_gen::Reply r{id,status,reason,uint8_t(running),active,wanted};
    irq_unlock(key);return r;
}
static scope_gen::Reply submit(const scope_gen::Request &r) {
    if(r.query) return reply(r.id,scope_control::APPLIED,scope_control::OK,active);
    if(have_last && r.id==last.id) {
        if(!scope_gen::equal(r.config,last.config))
            return reply(r.id,scope_control::REJECTED,scope_control::ID_CONFLICT,r.config);
        return reply(r.id,scope_gen::valid(r.config)?scope_control::APPLIED:scope_control::REJECTED,
            scope_gen::valid(r.config)?scope_control::OK:scope_control::UNSUPPORTED,r.config);
    }
    last=r;have_last=true;
    if(!scope_gen::valid(r.config)) return reply(r.id,scope_control::REJECTED,scope_control::UNSUPPORTED,r.config);
    apply(r.config);return reply(r.id,scope_control::APPLIED,scope_control::OK,r.config);
}
static void start() {
    analogWriteResolution(12);analogWrite(DAC_OUTPUT,0);
    // Untriggered conversion: each DHR write reaches the output automatically.
    reinterpret_cast<DAC_TypeDef *>(DAC1_BASE)->CR &= ~DAC_CR_TEN1;
    k_timer_init(&timer,tick,nullptr);apply(scope_gen::defaults());
    k_timer_start(&timer,K_TICKS(CONFIG_SYS_CLOCK_TICKS_PER_SEC/scope_gen::UPDATE_HZ),
        K_TICKS(CONFIG_SYS_CLOCK_TICKS_PER_SEC/scope_gen::UPDATE_HZ));
}
}
