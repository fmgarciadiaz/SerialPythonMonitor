# Osciloscopio DMA_TXRX — firmware V3 para Arduino Core Zephyr 1.0.0

Versión preparada el 29/09/2026 sobre el firmware V2 que ya funcionaba en el Q.
Aplicación separada en App Lab: **Osciloscopio DMA_TXRX V3**. La V2 se conserva
en su carpeta original; las tareas del proyecto apuntan ahora a V3.

## Configuración conservada

- UNO Q / STM32U585, A0 y A1, ADC de 14 bits a 10.000 pares/s.
- TIM2 dispara la adquisición; TIM5 aporta timestamps de hardware en µs.
- GPDMA1 canales 0 y 1, dos nodos de 2048 pares (204,8 ms por nodo).
- Serial1 a 1.100.000 baudios, paquetes de 512 pares.
- A2 cambia de estado cada 200 ms; mismo hilo, pila y prioridad que V2.
- Arranque: observar adquisición en nodo 0, limpiar TC iniciales, esperar que
  ambos canales estén en nodo 1 con nuevas TC antes de entregar el primer nodo.
- Python del Q y protocolo de comunicación con el monitor/R4 sin cambios.

## Organización

- `sketch/scope_config.h`: pines, frecuencias, tamaños, prioridades y comprobaciones de compilación.
- `sketch/scope_protocol.h`: muestra de 8 bytes y paquete DATA de 4103 bytes, sin padding.
- `sketch/sketch.ino`: configuración de periféricos, hilos y consumidor serial.
- `sketch/sketch.yaml`: perfil fijado a `arduino:zephyr (1.0.0)`.

## Cambios respecto de V2

Se retiró la capa de compatibilidad de Core 0.90.0 que redefinía funciones LL
y operaciones de caché con símbolos débiles. ADC y temporizadores usan funciones
inline de los encabezados STM32 incluidos en Core 1.0.0. La construcción de los
dos anillos DMA usa una única función local para el formato lineal fijo
CTR1/CTR2/CBR1/CSAR/CDAR/CLLR, conservando los anchos y longitudes de origen/destino.

El enlace dinámico de App Lab no exporta `cache_data_flush_range` ni
`cache_data_invd_range`: figuran en `syms-static.ld`, pero no en
`syms-dynamic.ld`. Por eso se usa una función local con las operaciones LL inline
del controlador **DCACHE1 del STM32U585**, protegida por `irq_lock()` en este MCU
mononúcleo. Usa el rango inclusivo del buffer y barreras de memoria, y respeta la
alineación de 16 bytes del core. No redefine símbolos de Zephyr ni escribe en
registros SCB codificados manualmente.

El perfil fija además RouterBridge 0.4.3, RPClite 0.3.1, MsgPack 0.4.2,
DebugLog 0.8.4, ArxTypeTraits 0.3.2 y ArxContainer 0.7.0. Los perfiles versionados
usan un entorno aislado: estas dependencias deben declararse en `sketch.yaml`,
aunque estén instaladas en el equipo. Arduino CLI las descarga al compilar.

El consumidor consulta DMA cada 1 ms en lugar de solicitar esperas de 50 µs.
Esto reduce sus despertares durante la espera; no cambia el disparo de hardware.
Cada paquete se envía normalmente en una sola llamada `Serial1.write`, en vez de
cuatro. Se completan posibles escrituras parciales sin repetir cabeceras.
No se cambió el driver UART del core ni se agregó DMA de transmisión UART.

## Validación y límites

La prueba `tests/test_scope_protocol.py` compila y ejecuta en el Mac el formato
y la función de envío reales, verificando todos los bytes frente al protocolo
anterior, incluyendo wrap del timestamp, escritura parcial y retorno cero.

Compilación local completada con Core 1.0.0 y enlace dinámico: 79.260 bytes
de programa y 74.231 bytes de RAM global. También se compiló en el Q con el
perfil versionado completo: 82.660 bytes de programa y 75.036 bytes de RAM global.
Las dos compilaciones usaron instalaciones de dependencias distintas (bibliotecas
locales frente al perfil aislado), por lo que no se presentan como binarios
idénticos ni como una medición comparativa de rendimiento. No se cargó firmware.
La versión debe probarse con una captura real después de cargarla. Compilar no
verifica la sincronización física, los tiempos de CPU, ni la calidad de la señal.
Se mantiene el consumidor ping-pong existente: una demora de transmisión superior
al margen del buffer puede causar pérdida/sobrescritura de muestras. No se agregó
una cola adicional ni recuperación automática de errores DMA en esta limpieza.

El respaldo exacto anterior está en
`respaldos/sketch_dma_txrx_v2_antes_zephyr1.ino.bak` en la raíz del repositorio.
Para recuperar V2, restaurar ese contenido en `sketch/sketch.ino` y recompilar;
los nuevos headers no se usan desde el sketch V2.

Referencias: [Arduino Core Zephyr 1.0.0](https://github.com/arduino/ArduinoCore-zephyr/tree/1.0.0),
[caché de Zephyr](https://docs.zephyrproject.org/latest/hardware/cache/guide.html),
[controlador DCACHE de ST](https://github.com/STMicroelectronics/stm32u5xx-hal-driver/blob/main/Src/stm32u5xx_hal_dcache.c).
