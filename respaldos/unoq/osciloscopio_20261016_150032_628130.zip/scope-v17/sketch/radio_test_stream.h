#pragma once
#include "radio_test.h"
// Share WAV's already allocated DAC RAM and guarded linked list. WAV and generator
// ownership are exclusive. A missing refill reaches a finite neutral descriptor,
// never a circular replay of stale DDS samples. Poll runs at CONTROL_HZ.
namespace radio_test {
static Oscillators oscillators;
static unsigned head=0,tail=0,used=0;
static void publish(const uint16_t *sine) {
    oscillators.fill(wav_hw::data[tail],scope_wav::POINTS,sine);
    cache_flush_invalidate(wav_hw::data[tail],sizeof(wav_hw::data[tail]));
    wav_hw::descriptor(tail,false,scope_wav::POINTS);
    __DSB();
    tail=(tail+1)%scope_wav::SLOTS;++used;
}
static bool start(const scope_gen::Config &c,const uint16_t *sine) {
    if(!wav_hw::prepare())return false;
    head=tail=used=0;oscillators.configure(c);
    // Prime only four blocks: bound control-request latency while ADC is live.
    // Subsequent timer ticks grow the reserve, keeping one neutral guard ahead.
    while(used<4)publish(sine);
    return wav_hw::start(head,RATE);
}
static bool poll(const uint16_t *sine) {
    if(wav_hw::errors() || !generator_hw::healthy())return false;
    const int current=wav_hw::current();
    if(current==-1)return true; // Initial linked-list load.
    if(current<0)return false;  // Neutral guard reached: explicit fault.
    unsigned distance=(unsigned(current)+scope_wav::SLOTS-head)%scope_wav::SLOTS;
    if(distance>=used)return false;
    while(distance--) {
        wav_hw::descriptor(head,true);
        head=(head+1)%scope_wav::SLOTS;--used;
    }
    if(used<=1)return false; // Preserve the existing WAV DMA safety reserve.
    // At most one block per tick bounds IRQ cost; never write the active buffer.
    if(used<scope_wav::SLOTS-1)publish(sine);
    return true;
}
}
