#pragma once
#include <stdint.h>
// Exact CH1 profiles with the validated SPI38/FIFO10 pipeline.
static inline int scope_high_rate(unsigned bits,unsigned channels,uint32_t ticks,unsigned pairs) {
    return channels==1 && ((bits==8 && ticks==114 && pairs==3456) ||
        (bits==10 && ticks==137 && pairs==5568) ||
        (bits==10 && ticks==140 && pairs==2784) ||
        (bits==12 && ticks==163 && pairs==4608) ||
        (bits==12 && ticks==172 && pairs==4608) ||
        (bits==14 && ticks==188 && pairs==1984) ||
        (bits==14 && ticks==192 && pairs==1984));
}
