"""Bounded live RADIO audio source for the existing 40 kHz A0 DAC stream."""
from collections import deque
from threading import Lock
import numpy as np

class RadioDacSource:
    live = True
    radio_audio = True
    rate = 40000
    minimum_blocks = 16
    duration_seconds = 24 * 3600

    def __init__(self, volume=.25):
        if not 0 <= volume <= 1:raise ValueError('Volumen Radio fuera de rango')
        self.target_blocks = self.minimum_blocks
        self._lock = Lock()
        self._chunks = deque()
        self._available = 0
        self._position = 0
        self._key = None
        self._volume = self._previous_volume = float(volume)
        self.closed = False
        self.error = None
        self.clipped_samples = 0
        self.retunes = 0
        self.played = 0
        self.accepted = 0

    def __len__(self):return self.rate * self.duration_seconds

    def set_volume(self, value):
        if not 0 <= value <= 1:raise ValueError('Volumen Radio fuera de rango')
        with self._lock:self._volume = float(value)

    def observe_status(self, status):
        with self._lock:
            self.played = int(status.played)
            self.accepted = int(status.accepted)

    def feed_result(self, result):
        audio = result.get('audio');key = result.get('radio_key')
        if audio is None or key is None:return
        values = np.asarray(audio, dtype=float) - result['settings'].radio_offset
        with self._lock:
            if self.closed or self.error:return
            if key[2] != self.rate:
                self.error = 'Radio A0 requiere FS SALIDA de RADIO a 40 kHz';return
            if self._key != key:
                if self._key is not None:self.retunes += 1
                self._chunks.clear();self._available = 0
                self._key = key
            if not np.isfinite(values).all():
                self.error = 'Radio A0: audio inválido';return
            if self._available + len(values) > self.rate:
                self.error = 'Radio A0 atrasada: buffer de audio completo'
                self._chunks.clear();self._available = 0;return
            if len(values):self._chunks.append(values.copy());self._available += len(values)

    def try_codes(self, start, end, levels=None):
        # This source has its own volume. WAV/Synth amplitude must not scale it.
        with self._lock:
            if self.closed or self.error or self._available < end-start:return None
            if start != self._position:raise ValueError('Posición Radio A0 discontinua')
            count = end-start
            parts=[];left=count
            while left:
                chunk=self._chunks.popleft();take=min(left,len(chunk))
                parts.append(chunk[:take]);left-=take
                if take<len(chunk):self._chunks.appendleft(chunk[take:])
            self._available-=count;self._position=end
            volume=(self._volume if self._previous_volume==self._volume else
                    np.linspace(self._previous_volume,self._volume,count))
            signal=np.concatenate(parts)*volume+1.65
            self._previous_volume=self._volume
            self.clipped_samples+=int(np.count_nonzero((signal<0)|(signal>3.3)))
            return np.rint(np.clip(signal,0,3.3)*(4095/3.3)).astype('<u2')

    def render_dac_codes(self,start,end,amplitude,offset):
        return self.try_codes(start,end,(amplitude,offset))

    def close(self):
        with self._lock:
            self.closed=True;self._chunks.clear();self._available=0
