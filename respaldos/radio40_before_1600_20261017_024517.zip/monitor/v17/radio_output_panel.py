"""Generator Radio: shared RADIO tuning/audio, independent A0 volume."""
import queue
from PyQt6 import QtCore,QtWidgets
from monitor.v17.radio_output import RadioDacSource
from monitor.v17.radio_am import radio_input_supported,radio_tuning_max

class RadioOutputPanel(QtWidgets.QWidget):
    def __init__(self,owner,dial_type=QtWidgets.QDial):
        super().__init__();self.owner=owner;self.source=None
        box=QtWidgets.QVBoxLayout(self);box.setContentsMargins(0,6,0,0);box.setSpacing(6)
        self.frequency=QtWidgets.QLabel('Sintonía del panel RADIO')
        self.frequency.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        box.addWidget(self.frequency)
        self.play=QtWidgets.QPushButton('▶ Play');self.play.clicked.connect(self.toggle)
        box.addWidget(self.play)
        label=QtWidgets.QLabel('Volumen · A0');label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter);box.addWidget(label)
        self.volume=dial_type();self.volume.setRange(0,100);self.volume.setValue(25)
        self.volume.setFixedSize(64,64);self.volume.setNotchesVisible(True)
        box.addWidget(self.volume,0,QtCore.Qt.AlignmentFlag.AlignCenter)
        self.value=QtWidgets.QLabel('25 %');self.value.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter);box.addWidget(self.value)
        self.volume.valueChanged.connect(self.volume_changed)
        self.state=QtWidgets.QLabel('Audio de RADIO → A0 · 40 kHz');self.state.setWordWrap(True);box.addWidget(self.state)
        self.timer=QtCore.QTimer(self);self.timer.setInterval(200);self.timer.timeout.connect(self.sync)

    def volume_changed(self,value):
        self.value.setText(f'{value} %')
        if self.source is not None:self.source.set_volume(value/100)

    def sync(self):
        owner=self.owner
        self.frequency.setText(f'RADIO · {owner.radio_frequency.value():g} kHz → A0')
        if self.source is not None and self.source.error:
            error=self.source.error;self.stop();self.state.setText(error)
        elif self.source is not None and not self.source.played:
            self.state.setText('Preparando audio de RADIO…')
        elif self.source is not None:
            self.state.setText('RADIO → A0 · recorte' if self.source.clipped_samples else 'RADIO → A0 · en vivo')

    def radio_changed(self):
        if self.source is not None and (not self.owner.radio_enabled.isChecked() or self.owner.radio_output_rate.currentData()!=40000):
            self.stop()
            if self.owner.radio_output_rate.currentData()!=40000:self.state.setText('Seleccionar FS SALIDA de RADIO a 40 kHz')
        self.sync()

    def toggle(self):
        owner=self.owner
        if self.source is not None:self.stop();return
        if owner.serial_worker is None or not owner._wav_capable:
            self.state.setText('Conectar Q para enviar RADIO a A0');return
        if owner.output_pending or owner._auto_apply_timer.isActive() or owner._wav_active or owner._wav_preparing or owner.spectral.bode.active:
            self.state.setText('Esperar que la salida esté libre');return
        if not radio_input_supported(owner.applied_configuration):
            self.state.setText('RADIO requiere adquisición CH1');return
        if owner.applied_configuration.rate > 599250:
            self.state.setText('Radio A0: reducir adquisición a 599,25 kHz o menos');return
        if not 5000<=owner.radio_frequency.value()*1000<=radio_tuning_max(owner.applied_configuration.actual_rate):
            self.state.setText('Sintonía fuera de banda');return
        if owner.radio_output_rate.currentData()!=40000:
            self.state.setText('Seleccionar FS SALIDA de RADIO a 40 kHz');return
        item=owner.wav_rate.findData(40000)
        if item<0 or not owner.wav_rate.model().item(item).isEnabled():
            self.state.setText('Q no confirmó salida de audio a 40 kHz');return
        source=RadioDacSource(self.volume.value()/100)
        try:
            owner.radio_enabled.setChecked(True)
            owner.serial_worker.set_radio_output_source(source)
            owner.serial_worker.request_wav(1,source,source.rate)
        except queue.Full:
            owner.serial_worker.set_radio_output_source(None);source.close()
            self.state.setText('Salida ocupada; intentar otra vez');return
        self.source=source;owner._wav_active=True;owner._wav_cancelled=False
        self.play.setText('■ Stop');owner._sync_wav_transport();self.timer.start();self.sync()

    def stop(self):
        if self.source is not None:
            self.source.close();self.source=None
            worker=self.owner.serial_worker
            if worker is not None:worker.set_radio_output_source(None)
            self.owner._stop_wav()
        self.timer.stop();self.play.setText('▶ Play');self.state.setText('Audio de RADIO → A0 · 40 kHz')

    def status(self,status):
        if self.source is not None and (int(status.state) in (0,3,4,5) or status.reason):
            message='Radio A0 detenida' if not status.reason and int(status.state) in (0,3) else 'Radio A0 interrumpida: faltó audio' if int(status.state)==4 else f'Radio A0: error {status.reason}'
            self.stop();self.state.setText(message)
