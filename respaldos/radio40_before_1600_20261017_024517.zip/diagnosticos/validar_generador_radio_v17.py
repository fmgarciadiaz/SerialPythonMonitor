"""Actual RADIO DSP -> live A0 streaming/retuning/volume; no firmware changes."""
import sys,json,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dataclasses import asdict
from unittest.mock import patch
from monitor.v17.qt_environment import prepare_platform_plugins
prepare_platform_plugins()
from PyQt6 import QtCore,QtWidgets
from monitor.v17.board_owner import board_owner
from diagnosticos.probar_audio_owner_v16 import require_exclusive_monitor
from monitor.v17.receiver.unoq_usb import Connection
from monitor.v17.receiver.unoq_config_receiver import OutputReceiver
from monitor.v17.receiver.unoq_acquisition import Configuration
from monitor.v17.receiver.unoq_generator import GeneratorConfig
from monitor.v17.receiver.unoq_switch import Mode
from monitor.v17.bode_calibration import instrument_identity
from monitor.v17.app import SerialMonitorWindow,OutputWorker


def main():
 report={'ok':False,'restored':False,'errors':[],'samples':0,'wav_states':[]}
 folder=ROOT/'diagnosticos/resultados_v17'/('generador_radio_'+time.strftime('%Y%m%d_%H%M%S'));folder.mkdir()
 app=QtWidgets.QApplication([]);report['qt_platform']=app.platformName()
 worker=thread=w=None;prior=None
 def save():(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 def exception(kind,value,tb):
  detail=''.join(traceback.format_exception(kind,value,tb));report['errors'].append(detail);save();print(detail,flush=True)
 sys.excepthook=exception
 with board_owner('1060031107','validar Generador Radio'):
  require_exclusive_monitor()
  try:
   with Connection('1060031107') as c:
    r=OutputReceiver(c,lambda b:None);r.decoder.numeric=True;r.select(Mode.SPI);g=r.generator().active
    if g.enabled:raise RuntimeError('Generador ocupado')
    prior={'adc':asdict(r.config),'generator':asdict(g)};report['prior']=prior
    r.configure(Configuration(14,40000))
   report['identity_before']=instrument_identity('1060031107');save()
   with patch('monitor.v17.app.usb_devices',return_value=[]):w=SerialMonitorWindow()
   w.generator_mode.setCurrentIndex(7)
   # Fixed real RF input and existing ADC firmware. No synthetic replacement.
   config=(Configuration(8,int(sys.argv[sys.argv.index('--rate')+1])) if '--rate' in sys.argv else Configuration(8,1600000) if '--fast' in sys.argv else Configuration(14,599250))
   w.config_bits_combo.setCurrentIndex(w.config_bits_combo.findData(config.bits))
   if w.config_rate_combo.findData(config.rate)<0:
    w.config_rate_combo.addItem(f'{config.rate} Hz (diagnóstico)',config.rate)
   w.config_rate_combo.setCurrentIndex(w.config_rate_combo.findData(config.rate))
   worker=OutputWorker('1060031107',Mode.SPI,config=config,processing_settings=w._processing_settings(),startup_gui_ack=True,processing_backend='process')
   w.serial_worker=worker;w.is_running=True;w.show()
   def confirmed(bits,rate):w._acquisition_confirmed(bits,rate);worker.confirm_startup(bits,rate)
   worker.acquisition_confirmed.connect(confirmed)
   worker.generator_confirmed.connect(w._generator_confirmed)
   def wav(status):
    if not report['wav_states'] or report['wav_states'][-1]['state']!=int(status.state):
     report['wav_states'].append({'state':int(status.state),'reason':int(status.reason),'played':int(status.played),'accepted':int(status.accepted)})
    if int(status.state)==2:report['max_played']=max(report.get('max_played',0),int(status.played))
    if int(status.state) in (4,5) or status.reason:report['errors'].append(f'WAV {status.state}/{status.reason}')
    w._wav_confirmed(status)
   worker.wav_confirmed.connect(wav)
   def collect(batch):report['samples']+=len(batch);w._deliver_worker_batch(worker,batch)
   worker.batch_ready.connect(collect);worker.error_occurred.connect(report['errors'].append)
   thread=QtCore.QThread();worker.moveToThread(thread);thread.started.connect(worker.run);worker.finished.connect(thread.quit)
   thread.start();start=time.monotonic();played_at=None;changed=set();source=None
   while time.monotonic()-start<40 and thread.isRunning():
    app.processEvents();time.sleep(.001)
    if played_at is None and w._wav_capable and w.applied_configuration==config:
     w.radio_frequency.setValue(550 if config.bits==8 else 20);w.radio_output_panel.toggle()
     source=w.radio_output_panel.source
     if source is not None:played_at=time.monotonic();report['play_started_seconds']=played_at-start
    if played_at is not None:
     elapsed=time.monotonic()-played_at
     if elapsed>8 and 'volume' not in changed:w.radio_output_panel.volume.setValue(50);changed.add('volume')
     if elapsed>12 and 'retune' not in changed:w.radio_frequency.setValue(575 if config.bits==8 else 25);changed.add('retune')
     if elapsed>17 and 'snapshot' not in changed:
      w.grab().save(str(folder/'radio_mode.png'));changed.add('snapshot')
     if elapsed>20 and 'stop' not in changed:w.radio_output_panel.stop();changed.add('stop')
     if elapsed>23 and not w._wav_active:break
   report.update(changed=sorted(changed),pending_peak=worker.pending_batches_peak,
     max_queue_delay_ms=w.batch_queue_delay_max_ms,radio_enabled_after_stop=w.radio_enabled.isChecked(),
     output_source_detached=w.radio_output_panel.source is None,adc=asdict(w.applied_configuration))
   if source is not None:report.update(retunes=source.retunes,source_error=source.error,clipped=source.clipped_samples)
   report['ok']=(not report['errors'] and report.get('max_played',0)>40000*10 and report['output_source_detached'] and 'stop' in changed and report.get('retunes',0)>=1 and w.applied_configuration==config)
  except BaseException as exc:
   report['errors'].append(repr(exc));report['traceback']=traceback.format_exc();raise
  finally:
   if worker:worker.stop()
   if thread:
    deadline=time.monotonic()+15
    while thread.isRunning() and time.monotonic()<deadline:app.processEvents();time.sleep(.001)
    if thread.isRunning():raise RuntimeError('Worker did not exit; no competing connection opened')
   if w:w.serial_worker=None;w.close()
   if prior is not None:
    with Connection('1060031107') as c:
     r=OutputReceiver(c,lambda b:None);r.decoder.numeric=True;r.select(Mode.SPI);r.configure(Configuration(14,40000))
    report['identity_after']=instrument_identity('1060031107');assert report['identity_after']==report['identity_before']
    with Connection('1060031107') as c:
     r=OutputReceiver(c,lambda b:None);r.decoder.numeric=True;r.select(Mode.SPI);r.configure(Configuration(**prior['adc']));r.generator(GeneratorConfig(**prior['generator']))
     final={'adc':asdict(r.config),'generator':asdict(r.generator().active)};before=r.decoder.pairs;end=time.monotonic()+10
     while time.monotonic()<end:r.pump()
     report.update(restored=final==prior,recovery={'samples':r.decoder.pairs-before,'status':r.decoder.status})
   save();print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
