import unittest
from concurrent.futures import Future
from types import SimpleNamespace
from unittest.mock import Mock,patch
import numpy as np
from monitor.v17.radio_output import RadioDacSource
from monitor.v17.processing import ProcessingSettings

class RadioOutputSourceTests(unittest.TestCase):
 def result(self,values,frequency=550000,rate=40000,generation=0):
  return dict(audio=np.asarray(values,dtype=float)+1.65,radio_key=(1403508,frequency,rate),
      generation=generation,settings=ProcessingSettings(radio_enabled=True,radio_offset=1.65,generation=generation))
 def test_order_buffering_volume_and_existing_wav_levels_are_independent(self):
  s=RadioDacSource(1);self.assertIsNone(s.try_codes(0,4))
  s.observe_status(SimpleNamespace(played=480,accepted=960))
  self.assertEqual((s.played,s.accepted),(480,960))
  s.feed_result(self.result([-.5,0,.5,1]))
  codes=s.try_codes(0,4,(0,0))
  np.testing.assert_array_equal(codes,np.rint(np.array([1.15,1.65,2.15,2.65])*4095/3.3).astype('<u2'))
  s.set_volume(0);s.feed_result(self.result([1]*8));s.try_codes(4,8)
  np.testing.assert_array_equal(s.try_codes(8,12),np.full(4,2048,dtype='<u2'))
  self.assertIsNone(s.try_codes(12,16))
 def test_retune_never_replays_old_audio(self):
  s=RadioDacSource(1);s.feed_result(self.result([1]*4));s.feed_result(self.result([-.5]*4,frequency=600000))
  self.assertEqual(s.retunes,1)
  np.testing.assert_array_equal(s.try_codes(0,4),np.full(4,round(1.15*4095/3.3),dtype='<u2'))
  s.close();s.feed_result(self.result([1]*10));self.assertIsNone(s.try_codes(4,8))
 def test_requires_demodulated_40k_without_resampling_and_bounds(self):
  s=RadioDacSource(1);s.feed_result(self.result(np.ones(4800)*.2,rate=48000))
  self.assertIn('40 kHz',s.error);self.assertIsNone(s.try_codes(0,480))
  s=RadioDacSource(1);s.feed_result(self.result(np.zeros(50000)));self.assertIn('buffer',s.error)
 def test_worker_feeds_exact_current_dsp_audio_before_gui_delivery(self):
  from monitor.v17.app import OutputWorker
  from monitor.v17.receiver.unoq_switch import Mode
  settings=ProcessingSettings(generation=2,radio_enabled=True)
  w=OutputWorker('offline',Mode.SPI,processing_settings=settings)
  source=RadioDacSource(1);w.set_radio_output_source(source)
  for generation in (1,2):
   f=Future();f.set_result(SimpleNamespace(processing=self.result([.4]*4,generation=generation)))
   w._processed(f)
  self.assertEqual(len(source.try_codes(0,4)),4)
  self.assertIsNone(source.try_codes(4,8))

class RadioOutputUiTests(unittest.TestCase):
 def test_separate_mode_mirrors_tuning_and_uses_radio_without_changing_adc(self):
  from PyQt6 import QtWidgets
  from monitor.v17.app import SerialMonitorWindow
  app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
  with patch('monitor.v17.app.usb_devices',return_value=[]):w=SerialMonitorWindow()
  try:
   w._acquisition_confirmed(14,599250);w.radio_frequency.setValue(20)
   w.generator_mode.setCurrentIndex(7)
   self.assertEqual(w.generator_mode.currentText(),'Radio')
   self.assertEqual(w.generator_mode.itemText(6),'Radio Test')
   self.assertTrue(w.radio_test_panel.isHidden());self.assertFalse(w.radio_output_panel.isHidden())
   self.assertTrue(w.wav_amplitude_box.isHidden());self.assertTrue(w.generator_offset_box.isHidden())
   worker=Mock();w.serial_worker=worker;w._wav_capable=True;w.output_pending=False
   w.wav_rate.model().item(w.wav_rate.findData(40000)).setEnabled(True)
   from monitor.v17.receiver.unoq_acquisition import Configuration
   valid_config=w.applied_configuration
   w.applied_configuration=Configuration(8,1403508)
   w.radio_output_panel.toggle();self.assertIsNone(w.radio_output_panel.source)
   worker.request_wav.assert_not_called()
   w.applied_configuration=valid_config
   w.radio_output_rate.setCurrentIndex(w.radio_output_rate.findData(48000))
   w.radio_output_panel.toggle();self.assertIsNone(w.radio_output_panel.source)
   worker.request_wav.assert_not_called()
   w.radio_output_rate.setCurrentIndex(w.radio_output_rate.findData(40000))
   before=w.applied_configuration
   w.radio_output_panel.toggle()
   self.assertTrue(w.radio_enabled.isChecked(),w.radio_output_panel.state.text());self.assertEqual(w.applied_configuration,before)
   source=w.radio_output_panel.source;self.assertIsInstance(source,RadioDacSource)
   worker.set_radio_output_source.assert_called_with(source);worker.request_wav.assert_called_once_with(1,source,40000)
   w.radio_frequency.setValue(25);self.assertIn('25',w.radio_output_panel.frequency.text())
   w.radio_output_panel.volume.setValue(0);self.assertEqual(w.radio_gain.value(),2)
   w.radio_output_rate.setCurrentIndex(w.radio_output_rate.findData(48000));self.assertIsNone(w.radio_output_panel.source)
   worker.request_wav.assert_called_with(3)
   w.serial_worker=None;w._wav_active=False
  finally:w.serial_worker=None;w.close();app.processEvents()
