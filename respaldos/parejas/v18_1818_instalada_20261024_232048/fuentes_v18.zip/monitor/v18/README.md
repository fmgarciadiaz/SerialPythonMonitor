# V18 · integración del monitor con adquisición en proceso separado

V18 tiene GUI y módulos propios, sin imports runtime de V17. La integración
se valida en esta carpeta; V17 se conserva como referencia sin modificarla.

```sh
python -m monitor.v18 --gui
python -m monitor.v18 --self-test
```

`--gui` abre el monitor; la conexión se inicia con Conectar. Usa Scope V18 y
el relay **ya instalados y activos** en el Q. No cambia firmware ni programas.
Sin opciones imprime el diagnóstico de desarrollo. `--self-test` ejecuta
pruebas locales, incluidas conexiones TCP localhost; no conecta con el Q.

La GUI utiliza `io/receiver_process.py`: transporte en hijo, DSP y fuentes
RADIO/FM en el padre, confirmaciones ordenadas, RF numérico y PCM acotado.
WAV de archivo usa mmap. El hijo mantiene el lock, guarda el estado inicial
y comprueba la restauración al cerrar. La desconexión puede tardar más de
diez segundos porque incluye recepción de recuperación.

El prototipo asíncrono `io/process_audio.py` permanece separado como material
de validación. Sus modelos no acreditan estabilidad física ni holgura.

La GUI pasó pruebas offline y validación con el Q: perfiles de las cinco
resoluciones, generador, WAV/seek a 20/40/50 kHz y RADIO/A0 durante 120 s a
8 bits/1,818 MS/s con tres pases independientes de 120 s en la pareja instalada.
IPC compacto automático para este perfil; Scan, WAV, Synth20, cierre y
recuperación de 10 s aprobados. Se conservan los cortes de ensayos anteriores
para seguimiento de estabilidad. Ver
[alcance y evidencia](../../docs/VALIDACION_V18.md); no implica calificación
prolongada de todas las combinaciones ni aceptación analógica.

[Plan y estado](../../docs/PLAN_INCORPORACION_V18.md) ·
[Base GUI](../../docs/BASE_GUI_V18.md) ·
[Manifiesto GUI](gui_migration_manifest.json) ·
[Auditoría histórica del núcleo](migration_audit.json).

## Pareja propia del Q

Desde la transición del23/10, la conexión exige Scope V18 y el relay
`serialmonitor-usb-stream-v18`. El monitor V17 se conserva con su app, firmware
y relay originales en un respaldo pareado; no se modifican sus fuentes.
[Manifiesto y transición](../../docs/PAREJAS_V17_V18.md).
