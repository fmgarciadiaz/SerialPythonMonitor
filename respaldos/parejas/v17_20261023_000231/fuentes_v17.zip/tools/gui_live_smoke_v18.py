#!/usr/bin/env python3
"""Bounded live GUI smoke. Sole Q owner required; never deploys firmware.

Run only when explicitly authorized. Writes JSON evidence for paint events,
RF/DSP/GUI and Radio A0 transitions; backend handles snapshot/restoration.
"""
import argparse
from collections import deque
from dataclasses import asdict
import json
from pathlib import Path
import sys
import time
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from PyQt6 import QtCore, QtWidgets
from monitor.v18.app import SerialMonitorWindow


class PaintCounter(QtCore.QObject):
    def __init__(self, parent=None):
        super().__init__(parent); self.events = 0
    def eventFilter(self, watched, event):
        if event.type() == QtCore.QEvent.Type.Paint: self.events += 1
        return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--serial', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--bits', type=int, default=8)
    parser.add_argument('--rate', type=int, default=1600000)
    parser.add_argument('--frequency-khz', type=float, default=550)
    parser.add_argument('--duration', type=float, default=32)
    parser.add_argument('--hold-radio-seconds', type=float, default=0,
        help='Hold actual confirmed RADIO PLAYING for this many seconds before Stop')
    parser.add_argument('--scan', action='store_true')
    parser.add_argument('--wav', action='store_true')
    parser.add_argument('--fm', action='store_true')
    parser.add_argument('--voices', type=int, choices=range(1,21), default=1)
    args = parser.parse_args()
    audio_tail = 17 if args.fm else 11 if args.wav else 5
    import tempfile
    import wave
    import numpy as np
    wav_directory = tempfile.TemporaryDirectory(prefix='scope-v18-smoke-')
    wav_path = Path(wav_directory.name)/'smoke_500hz.wav'
    if args.wav:
        with wave.open(str(wav_path), 'wb') as stream:
            stream.setnchannels(1); stream.setsampwidth(2); stream.setframerate(20000)
            stream.writeframes((np.sin(2*np.pi*500*np.arange(80000)/20000)*8000).astype('<i2').tobytes())
    app = QtWidgets.QApplication([])
    app.setQuitOnLastWindowClosed(False)
    evidence = dict(started=time.time(), stages=[], errors=[], paint_events=0,
        scan=dict(requested=False, completed=False, candidate_count=None), assertions={})
    statuses = deque(maxlen=2048)
    class Window(SerialMonitorWindow):
        def _publish_radio_scan(self, peaks):
            super()._publish_radio_scan(peaks)
            evidence['scan'].update(completed=True, candidate_count=len(peaks))
        def _on_worker_error(self, message):
            evidence['errors'].append(str(message))
            self._set_connection_status(str(message)); self.stop_input()
    window = Window()
    counter = PaintCounter(window)
    window.plot_widget.viewport().installEventFilter(counter)
    start = time.monotonic()
    state = dict(connected=False, radio=False, a0=False, retuned=False, stopped=False,
                 closing=False, saved=False, scan=False, scan_recorded=False, wav_requested=False,
                 wav_play=False, radio_playing_at=None, radio_session=None, wav_session=None,
                 radio_stop_confirmed=False, radio_played=0, radio_accepted=0,
                 wav_stop_confirmed=False, wav_playing=False,
                 wav_progress=False, last_status_at=0., last_status_key=None, periodic_at=0.,
                 periodic_paints=0, stop_at=None, fm_requested=False, fm_play=False,
                 fm_playing=False, fm_session=None, fm_progress=False, fm_stop_confirmed=False)
    def observe_wav(status):
        now = time.monotonic()-start
        value = int(status.state)
        if state['a0'] and not state['wav_play'] and value == 2 and status.rate == 40000:
            if state['radio_playing_at'] is None:
                state['radio_playing_at'] = now
                state['radio_session'] = status.session
                record('radio_a0_playing_confirmed')
        if state['fm_play'] and value == 2 and status.session not in (state['radio_session'], state['wav_session']):
            if not state['fm_playing']: record('fm_playing_confirmed')
            state['fm_playing'] = True; state['fm_session'] = status.session
        if state['wav_play'] and not state['fm_play'] and value == 2 and status.session != state['radio_session']:
            if not state['wav_playing']: record('wav_playing_confirmed')
            state['wav_playing'] = True; state['wav_session'] = status.session
        if status.session == state['radio_session']:
            state['radio_played']=max(state['radio_played'], status.played)
            state['radio_accepted']=max(state['radio_accepted'], status.accepted)
        if status.session == state['radio_session'] and state['stopped'] and value in (0, 3):
            state['radio_stop_confirmed'] = True
        if status.session == state['wav_session']:
            state['wav_progress'] |= status.played > 0
            if value in (0, 3): state['wav_stop_confirmed'] = True
        if status.session == state['fm_session']:
            state['fm_progress'] |= status.played > 0
            if value in (0, 3): state['fm_stop_confirmed'] = True
        phase = ('fm' if status.session == state['fm_session'] else
                 'radio' if status.session == state['radio_session'] else
                 'wav' if status.session == state['wav_session'] else 'initial')
        key = (status.session, value, status.reason, phase)
        if key != state['last_status_key'] or now-state['last_status_at'] >= .5:
            statuses.append(dict(elapsed=now, phase=phase, **asdict(status)))
            state['last_status_key']=key; state['last_status_at']=now
        if phase in ('radio', 'wav', 'fm') and (value in (4, 5) or status.reason):
            evidence['errors'].append(f'{phase} status state={value} reason={status.reason}')
        if phase == 'radio' and state['radio_playing_at'] is not None and not state['stopped'] and value in (0, 3):
            evidence['errors'].append('Radio A0 stopped before the requested hold completed')

    def record(stage):
        source = window.radio_output_panel.source
        worker = window.serial_worker
        evidence['stages'].append(dict(stage=stage, elapsed=time.monotonic()-start,
            samples=window.sample_counter, paint_events=counter.events,
            exposed=window.windowHandle().isExposed() if window.windowHandle() else False,
            radio_samples=getattr(window.radio_stream, 'counter', 0),
            batch_processing_count=window.batch_processing_count,
            pending_gui=getattr(worker, 'pending_batches', 0),
            pending_dsp=getattr(worker, 'pending_dsp', 0),
            pending_gui_peak=getattr(worker, 'pending_batches_peak', 0),
            pending_dsp_peak=getattr(worker, 'pending_dsp_peak', 0),
            gui_delay_max_ms=window.batch_queue_delay_max_ms,
            retained_seconds=getattr(getattr(worker, 'delivery_budget', None), 'seconds', 0),
            radio_playing_seconds=(time.monotonic()-start-state['radio_playing_at']) if state['radio_playing_at'] is not None and not state['stopped'] else None,
            wav_active=window._wav_active, radio_a0=source is not None,
            radio_a0_diagnostics=source.diagnostics() if source is not None else None,
            status=window.status_label.text()))
    def save():
        if state['saved']: return
        state['saved'] = True
        held = (state['stop_at']-state['radio_playing_at'] if state['stop_at'] is not None and state['radio_playing_at'] is not None else 0.)
        evidence['assertions'] = dict(
            radio_playing_40k=state['radio_playing_at'] is not None,
            radio_stop_confirmed=state['radio_stop_confirmed'],
            radio_progress=state['radio_played']>0,
            radio_hold_completed=held >= args.hold_radio_seconds,
            scan_completed=not args.scan or evidence['scan']['completed'],
            wav_playing=not args.wav or state['wav_playing'],
            wav_progress=not args.wav or state['wav_progress'],
            wav_stop_confirmed=not args.wav or state['wav_stop_confirmed'],
            fm_playing=not args.fm or state['fm_playing'],
            fm_progress=not args.fm or state['fm_progress'],
            fm_stop_confirmed=not args.fm or state['fm_stop_confirmed'],
            shutdown_confirmed=bool(window._shutdown_status and window._shutdown_status[0]),
            worker_released=window.serial_worker is None)
        for name, passed in evidence['assertions'].items():
            if not passed: evidence['errors'].append(f'Assertion failed: {name}')
        evidence['radio_hold_seconds'] = held
        evidence['radio_played_samples'] = state['radio_played']
        evidence['radio_accepted_samples'] = state['radio_accepted']
        evidence['wav_statuses'] = list(statuses)
        evidence.update(finished=time.time(), paint_events=counter.events,
            exposed=window.windowHandle().isExposed() if window.windowHandle() else False,
            shutdown_status=window._shutdown_status,
            closed=not window.isVisible(), worker_released=window.serial_worker is None)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(evidence, indent=2, default=str)+'\n')
        print(json.dumps(dict(output=str(args.output), errors=evidence['errors'],
            paint_events=counter.events, shutdown_status=window._shutdown_status)), flush=True)
        app.quit()
    def tick():
        elapsed = time.monotonic()-start
        end_at = max(args.duration, (state['radio_playing_at'] or 0)+args.hold_radio_seconds+audio_tail)
        try:
            if elapsed-state['periodic_at'] >= 10:
                interval=elapsed-state['periodic_at']
                record('periodic')
                evidence['stages'][-1]['paint_fps_interval']=(counter.events-state['periodic_paints'])/interval
                state['periodic_at']=elapsed; state['periodic_paints']=counter.events
            if state['a0'] and state['radio_playing_at'] is None and elapsed>25:
                evidence['errors'].append('Radio A0 never confirmed PLAYING at 40 kHz')
            if not state['connected']:
                state['connected']=True
                window.port_combo.addItem(args.serial, args.serial)
                window.port_combo.setCurrentIndex(window.port_combo.count()-1)
                window.config_bits_combo.setCurrentIndex(window.config_bits_combo.findData(args.bits))
                window.config_rate_combo.setCurrentIndex(window.config_rate_combo.findData(args.rate))
                window.radio_output_rate.setCurrentIndex(window.radio_output_rate.findData(40000))
                window.connect_serial()
                if window.serial_worker is not None:
                    window.serial_worker.wav_confirmed.connect(observe_wav)
                record('connect_requested')
            if window.connection_state == 'connected' and not state['radio']:
                state['radio']=True
                window.radio_frequency.setValue(args.frequency_khz)
                window.radio_enabled.setChecked(True); record('radio_play')
            if args.scan and state['radio'] and not state['scan'] and elapsed>=5:
                state['scan']=True; evidence['scan']['requested']=True
                window._radio_scan(); record('radio_scan')
            if evidence['scan']['completed'] and not state['scan_recorded']:
                state['scan_recorded']=True; record('radio_scan_completed')
                evidence['stages'][-1]['candidate_count']=evidence['scan']['candidate_count']
            if state['radio'] and not state['a0'] and elapsed>=7 and window._wav_capable and window._radio_scan_future is None:
                state['a0']=True; window.radio_output_panel.toggle(); record('radio_a0_play')
            if state['a0'] and not state['retuned'] and elapsed>=13:
                state['retuned']=True
                window.radio_frequency.setValue(args.frequency_khz+1); record('radio_retune')
            if not state['stopped'] and elapsed>=end_at-audio_tail:
                state['stopped']=True; state['stop_at']=elapsed; record('before_stop')
                window.radio_output_panel.stop(); window.radio_enabled.setChecked(False)
            if args.wav and state['stopped'] and not state['wav_requested'] and not window._wav_active:
                state['wav_requested']=True
                window.generator_mode.setCurrentIndex(4)
                window.config_rate_combo.setCurrentIndex(window.config_rate_combo.findData(40000))
                window.apply_output(); window._wav_file_selected(str(wav_path)); record('wav_configure')
            if state['wav_requested'] and not state['wav_play'] and window.applied_configuration.rate<=100000 and not window.output_pending and not window._auto_apply_timer.isActive():
                state['wav_play']=True; window._play_wav(); record('wav_play_requested')
            if args.wav and state['wav_play'] and elapsed>=end_at-(9 if args.fm else 2) and window._wav_active and not state['fm_requested']:
                record('wav_before_stop'); window._stop_wav()
            if args.fm and state['stopped'] and not state['fm_requested'] and not window._wav_active and (not args.wav or state['wav_playing']):
                state['fm_requested']=True
                window.generator_mode.setCurrentIndex(5)
                window.config_rate_combo.setCurrentIndex(window.config_rate_combo.findData(40000))
                window.apply_output(); record('fm_configure')
            if state['fm_requested'] and not state['fm_play'] and window.applied_configuration.rate<=40000 and not window.output_pending and not window._auto_apply_timer.isActive():
                state['fm_play']=True; window.fm_panel.toggle()
                if window.fm_panel.source is not None and args.voices>1:
                    from dataclasses import replace
                    source=window.fm_panel.source
                    source.update(replace(source.parameters,notes=tuple((note,100) for note in range(48,48+args.voices))))
                record('fm_play_requested')
                evidence['stages'][-1]['requested_voices']=args.voices
            if state['fm_play'] and elapsed>=end_at-2 and window._wav_active:
                record('fm_before_stop'); window.fm_panel.toggle()
            if not state['closing'] and (elapsed>=end_at or evidence['errors']):
                state['closing']=True; record('before_close'); window.close()
            if state['closing'] and not window.isVisible(): save()
            # Never terminate the owner while restoration is running; report a
            # timeout and keep waiting for its bounded backend shutdown.
            if elapsed>end_at+65 and not state['saved']:
                evidence['errors'].append('GUI close exceeded restoration deadline')
                record('close_timeout'); save()
        except Exception as exc:
            evidence['errors'].append(f'{type(exc).__name__}: {exc}')
            state['closing']=True; window.close()
    window.show()
    timer = QtCore.QTimer(); timer.timeout.connect(tick); timer.start(100)
    app.exec()
    wav_directory.cleanup()
    return 1 if evidence['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
