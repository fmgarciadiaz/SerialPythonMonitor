"""Compact RF delivery: wire-width arrays cross IPC, voltages stay in the host."""
from dataclasses import dataclass
import time
import numpy as np
from monitor.v18.numeric_batch import NumericBatch

@dataclass
class RawRfBatch:
    samples: np.ndarray
    acquisition: object
    receiver_generation: int
    receiver_batch_id: int
    published_at: float

    def __len__(self):
        return len(self.samples)

    def materialize(self, clock):
        batch = NumericBatch(self.samples, self.acquisition.maximum, clock,
                             self.acquisition.channels)
        batch.acquisition = self.acquisition
        batch.receiver_generation = self.receiver_generation
        batch.receiver_batch_id = self.receiver_batch_id
        batch.published_at = self.published_at
        return batch
